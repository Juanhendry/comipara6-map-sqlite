"use client";
import { useState, useEffect, useRef, useCallback, useMemo, memo } from "react";

// ─── SHARED DATA (loaded from API) ───────────────────────────────────────────
const DEFAULT_FANDOMS=["Genshin Impact","Honkai Star Rail","Blue Archive","Hololive","Nijisanji","Attack on Titan","Demon Slayer","Jujutsu Kaisen","One Piece","Naruto","BTS","ENHYPEN","SEVENTEEN","Stray Kids","NewJeans","Valorant","League of Legends","Minecraft","Elden Ring","Final Fantasy","My Hero Academia","Spy x Family","Chainsaw Man","Frieren","Bocchi the Rock","Vtuber Original","Original Art","Webtoon","Light Novel","Cosplay","Arknights","Honkai Impact","Gachiakuta","Gakuen Idolmaster","Arknights Endfield"];

function getSearchCounts(){try{return JSON.parse(localStorage.getItem("cp6_sc")||"{}");}catch{return{};}}
function incrementSearch(f){const c=getSearchCounts();c[f]=(c[f]||0)+1;localStorage.setItem("cp6_sc",JSON.stringify(c));}
function getTopFandoms(fandoms,n=12){const c=getSearchCounts();return[...fandoms].sort((a,b)=>(c[b]||0)-(c[a]||0)).slice(0,n);}

// ─── GEOMETRY ─────────────────────────────────────────────────────────────────
// Booth dimensions
const BW=28, BH=20, BG=3;   // merchant booth width/height/gap
const INNER=3;               // gap between left & right col in a cluster
const AISLE=28;              // aisle between clusters
const CW_CLUSTER=2*BW+INNER+AISLE; // total width of one A-M cluster

// Layout anchors
const LETTERS=["A","B","C","D","E","F","G","H","I","J","K","L","M"];
const pad=n=>String(n).padStart(2,"0");

// Left margin (space for Visitor Bathroom + X03/X04/X05 labels)
const LEFT_MARGIN=90;
// N/O row Y
const N_Y=26;
// Merchant cluster area
const MER_X=LEFT_MARGIN+2;       // first merchant cluster left edge
const MER_GAP_TOP=52;            // gap from N row to upper merchant block
const UY=N_Y+20+MER_GAP_TOP;     // top of upper merchant block (A09–A24, etc.)
const UPPER_ROWS=8;              // booths per col in upper block (9..16 left, 17..24 right)
const AISLE_MID_H=32;           // vertical gap between upper and lower merchant blocks
const LY=UY+UPPER_ROWS*(BH+BG)+AISLE_MID_H; // top of lower merchant block

// P booths area: right of M cluster
const P_GAP=22;                  // gap between M cluster and P booths

// Bottom strip Y
const BOT_STRIP_GAP=32;         // gap below lower merchant block
const BOT_STRIP_Y=LY+UPPER_ROWS*(BH+BG)+BOT_STRIP_GAP;
const BOT_STRIP_H=80;           // height of bottom facilities strip

// Outdoor separator
const INDOOR_RIGHT_PAD=24;      // padding right of indoor content
const OUTDOOR_SEP=20;           // width of separator strip
const OUTDOOR_PAD=18;           // padding left inside outdoor

// Outdoor booth sizes (larger than indoor)
const OBW=38, OBH=24, OBG=8;

function buildPositions(){
  const pos={};

  // ── N booths: N01-N16, horizontal row, pairs side-by-side ─────────────────
  // N01|N02  N03|N04 ... N15|N16 — 8 clusters of 2
  for(let i=1;i<=16;i++){
    const pair=Math.floor((i-1)/2);
    const side=(i-1)%2;
    pos["N"+pad(i)]={cx: MER_X + pair*CW_CLUSTER + side*(BW+INNER) + BW/2, cy: N_Y+BH/2};
  }

  // ── O booths: O01-O18, same row, starting after a gap ─────────────────────
  // From image: O starts roughly where K/L/M columns are (rightish)
  // Gap between N and O sections (there's a gray zone/sponsor block between them)
  const O_GAP_CLUSTERS=1; // visual gap (approx 1 cluster width) between N and O sections
  const N_END_PAIR=8; // N has 8 pairs
  const O_START_X = MER_X + (N_END_PAIR + O_GAP_CLUSTERS) * CW_CLUSTER;
  for(let i=1;i<=18;i++){
    const pair=Math.floor((i-1)/2);
    const side=(i-1)%2;
    pos["O"+pad(i)]={cx: O_START_X + pair*CW_CLUSTER + side*(BW+INNER) + BW/2, cy: N_Y+BH/2};
  }

  // ── A–M merchant clusters ──────────────────────────────────────────────────
  // Each letter has 2 vertical columns. From the image:
  //   Upper block: left col = [A16 down to A09], right col = [A17 down to A24]  (8 rows each)
  //   Lower block: left col = [A08 down to A01], right col = [A25 down to A32]  (8 rows each)
  LETTERS.forEach((l,li)=>{
    const clX = MER_X + li*CW_CLUSTER;
    const lx  = clX;          // left column x
    const rx  = clX+BW+INNER; // right column x

    // Upper block — left col descending: 16,15,14,13,12,11,10,9
    [16,15,14,13,12,11,10,9].forEach((n,ri)=>{
      pos[l+pad(n)]={cx:lx+BW/2, cy:UY+ri*(BH+BG)+BH/2};
    });
    // Upper block — right col descending: 17,18,19,20,21,22,23,24
    [17,18,19,20,21,22,23,24].forEach((n,ri)=>{
      pos[l+pad(n)]={cx:rx+BW/2, cy:UY+ri*(BH+BG)+BH/2};
    });
    // Lower block — left col descending: 8,7,6,5,4,3,2,1
    [8,7,6,5,4,3,2,1].forEach((n,ri)=>{
      pos[l+pad(n)]={cx:lx+BW/2, cy:LY+ri*(BH+BG)+BH/2};
    });
    // Lower block — right col descending: 25,26,27,28,29,30,31,32
    [25,26,27,28,29,30,31,32].forEach((n,ri)=>{
      pos[l+pad(n)]={cx:rx+BW/2, cy:LY+ri*(BH+BG)+BH/2};
    });
  });

  // ── P booths: right of M cluster ──────────────────────────────────────────
  // From image: P section has 3 sub-groups with gaps between them:
  //   Group 1 (upper): P14|P15, P13|P16, P12|P17, P11|P18, P10|P19  (5 rows)
  //   Group 2 (mid):   P09|P20, P08|P21, P07|P22, P06|P23            (4 rows)
  //   Group 3 (lower): P05|P24, P04|P25, P03|P26, P02|P27, P01|P28  (5 rows)
  const PX = MER_X + LETTERS.length*CW_CLUSTER + P_GAP;
  const pGroups=[
    [[14,15],[13,16],[12,17],[11,18],[10,19]],
    [[9,20],[8,21],[7,22],[6,23]],
    [[5,24],[4,25],[3,26],[2,27],[1,28]],
  ];
  const P_GROUP_GAP=14; // vertical gap between P sub-groups
  let pRow=0;
  pGroups.forEach((grp,gi)=>{
    if(gi>0) pRow+=P_GROUP_GAP/(BH+BG)+0.5;
    grp.forEach(([l,r])=>{
      const cy=UY+pRow*(BH+BG)+BH/2;
      pos["P"+pad(l)]={cx:PX+BW/2, cy};
      pos["P"+pad(r)]={cx:PX+BW+INNER+BW/2, cy};
      pRow++;
    });
  });

  // ── R booths: bottom community zone + right wall ───────────────────────────
  // From image (bawah.png):
  //   R01 = standalone left of community zone
  //   R02-R10 = horizontal row along bottom
  //   R11, R12 = right wall vertical stack (indoor right edge)
  const R_BOT_Y = BOT_STRIP_Y + BOT_STRIP_H/2;
  // R01 — far left, standalone
  pos["R01"]={cx: MER_X+30, cy: R_BOT_Y};
  // R02–R10 — horizontal row in community zone
  const R_ROW_START_X = MER_X+95;
  const R_STEP=52;
  for(let i=2;i<=10;i++){
    pos["R"+pad(i)]={cx: R_ROW_START_X+(i-2)*R_STEP+OBW/2, cy: R_BOT_Y};
  }
  // R11, R12 — right side vertical
  const R_WALL_X = PX + 2*BW+INNER + 26;
  pos["R11"]={cx: R_WALL_X+OBW/2, cy: BOT_STRIP_Y+BOT_STRIP_H*0.65};
  pos["R12"]={cx: R_WALL_X+OBW/2, cy: BOT_STRIP_Y+BOT_STRIP_H*0.25};

  // ── Outdoor starts after indoor right edge ─────────────────────────────────
  const INDOOR_END_X = R_WALL_X + OBW + INDOOR_RIGHT_PAD;
  const OD_X = INDOOR_END_X + OUTDOOR_SEP + OUTDOOR_PAD;

  // X15–X19: vertical strip on the left edge of outdoor, right wall of indoor
  const X_RIGHT_Y=[UY+30, UY+90, UY+150, UY+210, UY+270];
  [15,16,17,18,19].forEach((n,i)=>{
    pos["X"+pad(n)]={cx: INDOOR_END_X-OBW/2-4, cy: X_RIGHT_Y[i]};
  });

  // S booths: outdoor right zone
  // From image (kanan.png): 4 columns × 4 rows (S01-S16) + S17 alone at bottom
  //   [S01 S02] [S03 S04]
  //   [S05 S06] [S07 S08]
  //   [S09 S10] [S11 S12]
  //   [S13 S14] [S15 S16]
  //   [S17]
  const S_X = OD_X+50;
  const S_Y = UY+10;
  const S_COL_W = OBW+OBG;
  const S_ROW_H = OBH+OBG*3;
  const S_PAIR_GAP = 22; // gap between left pair and right pair
  [[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16]].forEach((row,ri)=>{
    row.forEach((n,ci)=>{
      const pairOffset = ci>=2 ? S_PAIR_GAP : 0;
      pos["S"+pad(n)]={cx: S_X+ci*S_COL_W+pairOffset+OBW/2, cy: S_Y+ri*S_ROW_H+OBH/2};
    });
  });
  pos["S17"]={cx: S_X+OBW/2, cy: S_Y+4*S_ROW_H+OBH/2};

  return pos;
}
const POS=buildPositions();

// Canvas sizes
const _indoorEndX = (() => {
  const PX_=MER_X+LETTERS.length*CW_CLUSTER+P_GAP;
  return PX_+2*BW+INNER+26+OBW+INDOOR_RIGHT_PAD;
})();
const CW_INDOOR = _indoorEndX;
// Outdoor: separator + pad + S booth area (4 cols × OBW + gaps + pair gap 22 + margin)
const CW=_indoorEndX+OUTDOOR_SEP+OUTDOOR_PAD+50+4*OBW+3*OBG+22+80;
const CH=BOT_STRIP_Y+BOT_STRIP_H+50;

// ─── AISLE WAYPOINTS ──────────────────────────────────────────────────────────
const A_TOP_Y   = UY-18;
const A_MID_Y   = (UY+UPPER_ROWS*(BH+BG)+LY)/2;
const A_BOT_Y   = LY+UPPER_ROWS*(BH+BG)+16;
const A_TIERS   = [A_TOP_Y, A_MID_Y, A_BOT_Y];

const AISLE_XS=[];
for(let li=0;li<=LETTERS.length;li++){
  AISLE_XS.push(MER_X+li*CW_CLUSTER-AISLE/2);
}
AISLE_XS.push(MER_X+LETTERS.length*CW_CLUSTER+P_GAP/2);

const AISLE_NODES={};
AISLE_XS.forEach((ax,ai)=>{
  A_TIERS.forEach((ay,ti)=>{
    AISLE_NODES[`_a${ai}_${ti}`]={cx:ax,cy:ay};
  });
});

const ALL_NODES={...POS,...AISLE_NODES};

// ─── GRAPH ────────────────────────────────────────────────────────────────────
function getAllBooths(){
  const ids=[];
  for(let i=1;i<=16;i++) ids.push("N"+pad(i));
  for(let i=1;i<=18;i++) ids.push("O"+pad(i));
  LETTERS.forEach(l=>{for(let n=1;n<=32;n++) ids.push(l+pad(n));});
  for(let i=1;i<=28;i++) ids.push("P"+pad(i));
  for(let i=1;i<=12;i++) ids.push("R"+pad(i));
  for(let i=1;i<=17;i++) ids.push("S"+pad(i));
  return ids;
}
const ALL_BOOTHS=getAllBooths();

function buildGraph(){
  const g={};
  Object.keys(ALL_NODES).forEach(id=>{g[id]=[];});

  for(let ai=0;ai<AISLE_XS.length;ai++){
    for(let ti=0;ti<A_TIERS.length;ti++){
      const cur=`_a${ai}_${ti}`;
      if(ti+1<A_TIERS.length){
        const nb=`_a${ai}_${ti+1}`;
        const d=Math.abs(A_TIERS[ti]-A_TIERS[ti+1]);
        g[cur].push({id:nb,d});g[nb].push({id:cur,d});
      }
      if(ai+1<AISLE_XS.length){
        const nb=`_a${ai+1}_${ti}`;
        const d=Math.abs(AISLE_XS[ai]-AISLE_XS[ai+1]);
        g[cur].push({id:nb,d});g[nb].push({id:cur,d});
      }
    }
  }

  ALL_BOOTHS.forEach(bid=>{
    const bp=POS[bid];if(!bp)return;
    const sorted=AISLE_XS.map((ax,ai)=>({ai,dx:Math.abs(bp.cx-ax)})).sort((a,b)=>a.dx-b.dx);
    sorted.slice(0,2).forEach(({ai,dx})=>{
      if(dx>CW_CLUSTER*1.5)return;
      A_TIERS.forEach((ay,ti)=>{
        const aid=`_a${ai}_${ti}`;
        const d=Math.hypot(bp.cx-AISLE_XS[ai],bp.cy-ay);
        g[bid].push({id:aid,d});g[aid].push({id:bid,d});
      });
    });
  });
  return g;
}
const GRAPH=buildGraph();

function aStar(start,goal){
  if(start===goal)return[start];
  if(!ALL_NODES[start]||!ALL_NODES[goal])return[];
  const h=(a,b)=>{const pa=ALL_NODES[a],pb=ALL_NODES[b];return pa&&pb?Math.hypot(pa.cx-pb.cx,pa.cy-pb.cy):0;};
  const open=new Set([start]),from={},gS={[start]:0},fS={[start]:h(start,goal)};
  while(open.size){
    let cur=null,lf=Infinity;
    open.forEach(id=>{const v=fS[id]??Infinity;if(v<lf){lf=v;cur=id;}});
    if(cur===goal){const p=[goal];let n=goal;while(from[n]){n=from[n];p.unshift(n);}return p;}
    open.delete(cur);
    for(const{id:nb,d}of(GRAPH[cur]||[])){
      const tg=(gS[cur]??Infinity)+d;
      if(tg<(gS[nb]??Infinity)){from[nb]=cur;gS[nb]=tg;fS[nb]=tg+h(nb,goal);open.add(nb);}
    }
  }
  return[start,goal];
}

function svgPath(ids){
  if(ids.length<2)return"";
  const pts=ids.map(id=>ALL_NODES[id]).filter(Boolean);
  if(pts.length<2)return"";
  let d=`M${pts[0].cx},${pts[0].cy}`;
  for(let i=1;i<pts.length-1;i++){const mx=(pts[i].cx+pts[i+1].cx)/2,my=(pts[i].cy+pts[i+1].cy)/2;d+=` Q${pts[i].cx},${pts[i].cy} ${mx},${my}`;}
  return d+` L${pts[pts.length-1].cx},${pts[pts.length-1].cy}`;
}

// ─── TENANTS ─────────────────────────────────────────────────────────────────
function buildTenants(users, catalogMap, pricesMap){
  const t={};
  users.forEach(u=>{
    if(!u.booths?.length)return;
    const catalog = catalogMap[u.id] || [];
    const prices  = pricesMap[u.id] || [];
    u.booths.forEach(b=>{t[b]={userId:u.id,user:u.name,fandoms:u.fandoms,catalog,prices,allBooths:u.booths};});
  });
  return t;
}

// ─── BOOTH RECT (memoized to prevent re-renders of all 500+ booths) ──────────
const BoothRect = memo(function BoothRect({id,state,onClick}){
  const p=POS[id];if(!p)return null;
  const isOutdoor=id.startsWith("R")||id.startsWith("S");
  const bw=isOutdoor?OBW:BW;
  const bh=isOutdoor?OBH:BH;
  const C={
    empty:    {fill:"#F8FAFC",stroke:"#CBD5E1",text:"#94A3B8"},
    occupied: {fill:"#F3E8FF",stroke:"#D8B4FE",text:"#9333EA"},
    matched:  {fill:"#7C3AED",stroke:"#5B21B6",text:"#FFF"},
    selected: {fill:"#A78BFA",stroke:"#7C3AED",text:"#FFF"},
    pathStart:{fill:"#10B981",stroke:"#047857",text:"#FFF"},
    pathEnd:  {fill:"#EF4444",stroke:"#B91C1C",text:"#FFF"},
    onPath:   {fill:"#F59E0B",stroke:"#D97706",text:"#FFF"},
  }[state]||{fill:"#F8FAFC",stroke:"#CBD5E1",text:"#94A3B8"};
  return(
    <g onClick={()=>onClick(id)} style={{cursor:"pointer"}} className="group">
      <rect x={p.cx-bw/2} y={p.cy-bh/2} width={bw} height={bh} rx={4} fill={C.fill} stroke={C.stroke} strokeWidth={1} className="transition-all duration-150 group-hover:brightness-95"/>
      <text x={p.cx} y={p.cy} textAnchor="middle" dominantBaseline="central" fontSize={isOutdoor?7.5:6.5} fontWeight={700} fill={C.text} fontFamily="system-ui,sans-serif" style={{userSelect:"none",pointerEvents:"none"}}>{id}</text>
    </g>
  );
});

// ─── MODAL ────────────────────────────────────────────────────────────────────
function BoothModal({boothId,tenant,onClose,onNavigate}){
  const[idx,setIdx]=useState(0);
  const cat=tenant?.catalog||[],prices=tenant?.prices||[];
  return(
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm"/>
      <div className="relative bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[90vh] flex flex-col overflow-hidden" style={{animation:"slideUp .3s cubic-bezier(.16,1,.3,1) forwards"}} onClick={e=>e.stopPropagation()}>
        <div className="flex justify-center pt-3 sm:hidden"><div className="w-10 h-1 bg-gray-200 rounded-full"/></div>
        <div className="shrink-0 px-6 py-4 border-b border-gray-100">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xl font-extrabold text-gray-900">Booth {boothId}</span>
                <span className="text-xs px-2.5 py-1 bg-violet-100 text-violet-700 font-semibold border border-violet-200 rounded-full">{tenant?.user}</span>
              </div>
              {tenant?.allBooths?.length>1&&(
                <div className="flex gap-1 mt-1.5 flex-wrap">
                  {tenant.allBooths.map(b=><span key={b} className={`text-[10px] px-2 py-0.5 rounded font-bold border ${b===boothId?"bg-violet-600 border-violet-600 text-white":"bg-violet-50 border-violet-200 text-violet-700"}`}>{b}</span>)}
                </div>
              )}
              <div className="flex flex-wrap gap-1.5 mt-2">
                {tenant?.fandoms.map(f=><span key={f} className="text-[10px] px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full font-medium">{f}</span>)}
              </div>
            </div>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 shrink-0 ml-2 transition-colors">✕</button>
          </div>
        </div>
        <div className="overflow-y-auto px-6 py-4 space-y-5 flex-1">
          <button onClick={()=>{onNavigate(boothId);onClose();}} className="w-full py-3 bg-violet-600 hover:bg-violet-700 text-white text-sm font-bold rounded-xl transition-all flex items-center justify-center gap-2 shadow-sm shadow-violet-200">🗺️ Tampilkan Rute ke Booth Ini</button>
          <div>
            <h3 className="text-sm font-bold text-gray-800 mb-3 flex items-center gap-2">Katalog<div className="h-px bg-gray-100 flex-1"/></h3>
            {cat.length===0
              ?<div className="text-center py-8 bg-gray-50 border border-dashed border-gray-200 rounded-2xl"><div className="text-3xl opacity-30 mb-2">🖼️</div><p className="text-xs text-gray-400">Belum ada katalog</p></div>
              :<div className="space-y-3">
                <div className="rounded-2xl overflow-hidden bg-gray-100 aspect-square">
                  <img src={cat[idx]?.url||cat[idx]} alt="catalog" className="w-full h-full object-cover" loading="lazy"/>
                </div>
                {cat.length>1&&<div className="flex gap-2 overflow-x-auto pb-1">{cat.map((img,i)=><button key={i} onClick={()=>setIdx(i)} className={`shrink-0 w-16 h-16 rounded-xl overflow-hidden border-2 transition-all ${i===idx?"border-violet-500":"border-transparent opacity-60 hover:opacity-100"}`}><img src={img?.url||img} alt="" className="w-full h-full object-cover" loading="lazy"/></button>)}</div>}
              </div>
            }
          </div>
          <div className="pb-4">
            <h3 className="text-sm font-bold text-gray-800 mb-3 flex items-center gap-2">Daftar Harga<div className="h-px bg-gray-100 flex-1"/></h3>
            {prices.length===0
              ?<div className="text-center py-6 bg-gray-50 border border-dashed border-gray-200 rounded-2xl"><p className="text-xs text-gray-400">Belum ada daftar harga</p></div>
              :<div className="bg-white border border-gray-200 rounded-2xl overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50"><tr><th className="text-left py-2.5 px-4 text-xs text-gray-500 font-semibold uppercase tracking-wider">Item</th><th className="text-right py-2.5 px-4 text-xs text-gray-500 font-semibold uppercase tracking-wider">Harga</th></tr></thead>
                  <tbody className="divide-y divide-gray-100">{prices.map((p,i)=><tr key={i} className="hover:bg-gray-50/50"><td className="py-3 px-4 text-gray-800 font-medium">{p.item}</td><td className="py-3 px-4 text-right font-bold text-violet-700">Rp {parseInt(p.price).toLocaleString("id-ID")}</td></tr>)}</tbody>
                </table>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────
export default function FloorMap(){
  const[users,setUsers]=useState([]);
  const[fandoms,setFandoms]=useState(DEFAULT_FANDOMS);
  const[tenants,setTenants]=useState({});
  const[search,setSearch]=useState("");
  const[selFandom,setSelFandom]=useState(null);
  const[suggestions,setSuggestions]=useState([]);
  const[showSugg,setShowSugg]=useState(false);
  const[selectedId,setSelectedId]=useState(null);
  const[modalId,setModalId]=useState(null);
  const[tab,setTab]=useState("search");
  const[pathFrom,setPathFrom]=useState("");
  const[pathTo,setPathTo]=useState("");
  const[fullPath,setFullPath]=useState([]);
  const[dispPath,setDispPath]=useState([]);
  const[showPath,setShowPath]=useState(false);
  const[tx,setTx]=useState(0);
  const[ty,setTy]=useState(0);
  const[scale,setScale]=useState(1);
  const containerRef=useRef(null);
  const[showMapTip,setShowMapTip]=useState(false);
  const lastTouch=useRef(null);
  const lastDist=useRef(null);
  const pinching=useRef(false);
  const clickTimer=useRef(null);
  const searchRef=useRef(null);

  //
  useEffect(()=>{
    // Tampilkan notifikasi penggunaan map (maks 3x per device)
    try{
      setShowMapTip(true);
    }catch{}
  },[]);

  // Load data from API on mount
  useEffect(()=>{
    async function loadData(){
      try{
        const[usersRes, fandomsRes] = await Promise.all([
          fetch("/api/users"),
          fetch("/api/fandoms"),
        ]);
        const usersData = await usersRes.json();
        const fandomsData = await fandomsRes.json();

        // Load catalogs and prices for users with booths
        const usersWithBooths = usersData.filter(u => u.booths?.length > 0);
        const catalogMap = {};
        const pricesMap = {};

        if(usersWithBooths.length > 0){
          const [catalogResults, priceResults] = await Promise.all([
            Promise.all(usersWithBooths.map(u => fetch(`/api/catalog?userId=${u.id}`).then(r=>r.json()).catch(()=>[]))),
            Promise.all(usersWithBooths.map(u => fetch(`/api/prices?userId=${u.id}`).then(r=>r.json()).catch(()=>[]))),
          ]);
          usersWithBooths.forEach((u, i) => {
            catalogMap[u.id] = catalogResults[i];
            pricesMap[u.id] = priceResults[i];
          });
        }

        setUsers(usersData);
        setFandoms(fandomsData);
        setTenants(buildTenants(usersData, catalogMap, pricesMap));
      }catch(err){
        console.error("Failed to load data:", err);
      }
    }
    loadData();
  },[]);

  useEffect(()=>{
    if(!search.trim()){setSuggestions([]);return;}
    const q=search.toLowerCase(),counts=getSearchCounts();
    setSuggestions(fandoms.filter(f=>f.toLowerCase().includes(q)&&f.toLowerCase()!==q).sort((a,b)=>(counts[b]||0)-(counts[a]||0)).slice(0,8));
  },[search,fandoms]);

  const searchTerm=selFandom||search;
  const isMatch=useCallback(id=>{
    if(!searchTerm)return false;
    const t=tenants[id];if(!t)return false;
    return t.fandoms.some(f=>f.toLowerCase().includes(searchTerm.toLowerCase()));
  },[searchTerm,tenants]);
  const matchedSet=useMemo(()=>new Set(ALL_BOOTHS.filter(isMatch)),[isMatch]);
  const pathBoothSet=useMemo(()=>new Set(dispPath),[dispPath]);
  const topFandoms=useMemo(()=>getTopFandoms(fandoms,12),[fandoms]);

  function clamp(x,y,s,W,H){
    const mw=CW*s,mh=CH*s;
    return{x:mw<W?(W-mw)/2:Math.min(0,Math.max(W-mw,x)),y:mh<H?(H-mh)/2:Math.min(0,Math.max(H-mh,y))};
  }

  // Fit to screen on mount
  useEffect(()=>{
    const el=containerRef.current;if(!el)return;
    const s=Math.min((el.clientWidth-8)/CW,(el.clientHeight-8)/CH,1);
    setScale(s);const c=clamp(0,0,s,el.clientWidth,el.clientHeight);setTx(c.x);setTy(c.y);
  },[]);

  function resetView(){
    const el=containerRef.current;if(!el)return;
    const s=Math.min((el.clientWidth-8)/CW,(el.clientHeight-8)/CH,1);
    setScale(s);const c=clamp(0,0,s,el.clientWidth,el.clientHeight);setTx(c.x);setTy(c.y);
  }

  // Touch & wheel
  useEffect(()=>{
    const el=containerRef.current;if(!el)return;
    const gW=()=>el.clientWidth,gH=()=>el.clientHeight;
    const gd=t=>Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY);
    const gm=t=>({x:(t[0].clientX+t[1].clientX)/2,y:(t[0].clientY+t[1].clientY)/2});
    const onTS=e=>{if(e.touches.length===2){pinching.current=true;lastDist.current=gd(e.touches);lastTouch.current=gm(e.touches);e.preventDefault();}else{pinching.current=false;lastTouch.current={x:e.touches[0].clientX,y:e.touches[0].clientY};}};
    const onTM=e=>{
      if(e.touches.length===2){e.preventDefault();const d=gd(e.touches),m=gm(e.touches),ds=d/(lastDist.current||d);
        setScale(ps=>{const ns=Math.min(Math.max(ps*ds,0.25),5);const dx=m.x-(lastTouch.current?.x||m.x),dy=m.y-(lastTouch.current?.y||m.y);setTx(px=>clamp(px+dx,0,ns,gW(),gH()).x);setTy(py=>clamp(0,py+dy,ns,gW(),gH()).y);return ns;});
        lastDist.current=d;lastTouch.current=m;
      }else if(e.touches.length===1&&!pinching.current){
        const dx=e.touches[0].clientX-(lastTouch.current?.x||0),dy=e.touches[0].clientY-(lastTouch.current?.y||0);
        setTx(px=>clamp(px+dx,0,scale,gW(),gH()).x);setTy(py=>clamp(0,py+dy,scale,gW(),gH()).y);
        lastTouch.current={x:e.touches[0].clientX,y:e.touches[0].clientY};
      }
    };
    const onTE=()=>{pinching.current=false;};
    const onW=e=>{
      e.preventDefault();const rect=el.getBoundingClientRect();const mx=e.clientX-rect.left,my=e.clientY-rect.top;const ds=e.deltaY<0?1.12:0.9;
      setScale(ps=>{const ns=Math.min(Math.max(ps*ds,0.25),5);const c=clamp(mx-(mx-tx)*(ns/ps),my-(my-ty)*(ns/ps),ns,gW(),gH());setTx(c.x);setTy(c.y);return ns;});
    };
    el.addEventListener("touchstart",onTS,{passive:false});el.addEventListener("touchmove",onTM,{passive:false});el.addEventListener("touchend",onTE);el.addEventListener("wheel",onW,{passive:false});
    return()=>{el.removeEventListener("touchstart",onTS);el.removeEventListener("touchmove",onTM);el.removeEventListener("touchend",onTE);el.removeEventListener("wheel",onW);};
  },[scale,tx,ty]);

  // Booth click: single=select group, double=modal
  function handleBoothClick(id){
    if(tab==="path"){
      if(!pathFrom){setPathFrom(id);return;}
      if(!pathTo&&id!==pathFrom){setPathTo(id);return;}
    }
    if(clickTimer.current){clearTimeout(clickTimer.current);clickTimer.current=null;if(tenants[id]){setModalId(id);setSelectedId(null);}}
    else{clickTimer.current=setTimeout(()=>{clickTimer.current=null;setSelectedId(prev=>prev===id?null:id);},270);}
  }

  function handleFindPath(){
    if(!pathFrom||!pathTo)return;
    const fp=aStar(pathFrom,pathTo);
    setFullPath(fp);
    setDispPath(fp.filter(id=>!id.startsWith("_a")));
    setShowPath(true);
  }
  function resetPath(){setPathFrom("");setPathTo("");setFullPath([]);setDispPath([]);setShowPath(false);}
  function selectSuggestion(f){incrementSearch(f);setSelFandom(f);setSearch(f);setSuggestions([]);setShowSugg(false);}

  // Selected group: all booths of same user
  const selectedGroup=useMemo(()=>{
    if(!selectedId)return new Set();
    const t=tenants[selectedId];if(!t)return new Set([selectedId]);
    return new Set(t.allBooths||[selectedId]);
  },[selectedId,tenants]);

  function getState(id){
    if(showPath){
      if(id===pathFrom)return"pathStart";
      if(id===pathTo)return"pathEnd";
      if(pathBoothSet.has(id))return"onPath";
    }
    if(matchedSet.has(id))return"matched";
    if(selectedGroup.has(id))return"selected";
    if(tenants[id])return"occupied";
    return"empty";
  }

  // ── Derived layout values ──────────────────────────────────────────────────
  const LOWER_BOT = LY+UPPER_ROWS*(BH+BG);
  const PX_val    = MER_X+LETTERS.length*CW_CLUSTER+P_GAP;
  const RZ_X      = PX_val;                        // P/creative zone x
  const R_WALL_X  = PX_val+2*BW+INNER+26;         // R11/R12 wall x
  const OD_SEP_X  = R_WALL_X+OBW+INDOOR_RIGHT_PAD; // outdoor separator x
  const OD_ZONE_X = OD_SEP_X+OUTDOOR_SEP;          // outdoor area start

  const zones=useMemo(()=>{
    const lBot=LY+UPPER_ROWS*(BH+BG);
    const stripY=lBot+BOT_STRIP_GAP;
    const stripH=BOT_STRIP_H;
    const pX=MER_X+LETTERS.length*CW_CLUSTER+P_GAP;
    const rWallX=pX+2*BW+INNER+26;
    const odSepX=rWallX+OBW+INDOOR_RIGHT_PAD;
    const odZoneX=odSepX+OUTDOOR_SEP;
    // Right zone x (Creative/Exhibitor/Cosplay zone column)
    const rzX=pX;
    // Creative zone — aligned with P upper group
    const creativeH=5*(BH+BG)+P_GROUP_GAP+4*(BH+BG)+14;
    const creativeY=UY-2;
    // Exhibitor zone — below creative, to the right of creative
    const exhibH=88;
    const exhibY=creativeY+creativeH+12;
    return[
      {label:"Visitor\nBathroom",      x:4,               y:UY,    w:LEFT_MARGIN-12, h:LOWER_BOT-UY,   f:"#F1F5F9",s:"#CBD5E1",t:"#475569"},
      {label:"Pixiv\nCreator Hall",     x:4,               y:BOT_STRIP_Y, w:LEFT_MARGIN-12, h:BOT_STRIP_H, f:"#FFF1F2",s:"#FECDD3",t:"#E11D48"},
      // ── Indoor bottom strip ─────────────────────────────────────────────
      {label:"Comipara\nGuild Area", x:MER_X-6,        y:stripY, w:240, h:stripH, f:"#F0F9FF",s:"#BAE6FD",t:"#0284C7"},
      {label:"Comic Class\nArea",    x:MER_X+240,       y:stripY, w:130, h:stripH, f:"#F0FDFA",s:"#99F6E4",t:"#0D9488"},
      {label:"Visitor\nStorage",     x:MER_X+376,       y:stripY, w:80,  h:stripH, f:"#F8FAFC",s:"#E2E8F0",t:"#64748B"},
      {label:"Community Zone",       x:MER_X+462,       y:stripY, w:rWallX-MER_X-468, h:stripH, f:"#FFF7ED",s:"#FED7AA",t:"#EA580C"},
      // Sub-items in bottom strip
      {label:"Information",          x:MER_X+14,        y:stripY+stripH-22, w:72, h:18, f:"#EFF6FF",s:"#BFDBFE",t:"#1D4ED8"},
      {label:"Quest\nBoard",         x:MER_X+92,        y:stripY+stripH-22, w:72, h:18, f:"#FFF7ED",s:"#FED7AA",t:"#EA580C"},
      {label:"Item Shop",            x:MER_X+172,       y:stripY+stripH-22, w:58, h:18, f:"#EFF6FF",s:"#BFDBFE",t:"#1D4ED8"},
      {label:"Ticket Box",           x:MER_X+376,       y:stripY+stripH-22, w:80, h:22, f:"#FEF2F2",s:"#FECACA",t:"#B91C1C"},
      {label:"Charging\nStation",    x:MER_X+490,       y:stripY+stripH-26, w:90, h:20, f:"#F0FDF4",s:"#BBF7D0",t:"#15803D"},
      {label:"Tabletop\nArea",       x:rWallX-110,      y:stripY+4,          w:80, h:stripH-12, f:"#F8FAFC",s:"#E2E8F0",t:"#64748B"},
      // ── Indoor right column (Creative / Exhibitor / Cosplay / Stage) ────
      {label:"Creative\nZone",       x:rzX+2*BW+INNER+10, y:creativeY, w:66, h:creativeH, f:"#F0FDF4",s:"#BBF7D0",t:"#16A34A"},
      {label:"Exhibitor\nZone",      x:rzX+2*BW+INNER+10, y:exhibY,    w:66, h:exhibH,    f:"#FDF2F8",s:"#FBCFE8",t:"#DB2777"},
      {label:"X07\n(Exhibitor)",     x:rzX+2*BW+INNER+82, y:UY+60,     w:70, h:130,       f:"#FDF2F8",s:"#FBCFE8",t:"#DB2777"},
      {label:"Community\nStage",     x:rzX+2*BW+INNER+82, y:N_Y,       w:130,h:80,        f:"#FEFCE8",s:"#FDE68A",t:"#92400E"},
      {label:"Visitor\nIdle Area",   x:rzX+2*BW+INNER+82, y:UY+200,    w:130,h:80,        f:"#F8FAFC",s:"#E2E8F0",t:"#64748B"},
      {label:"Cosplay\nReg Zone",    x:rzX+2*BW+INNER+82, y:LY-16,     w:80, h:UPPER_ROWS*(BH+BG)+30, f:"#FAF5FF",s:"#E9D5FF",t:"#9333EA"},
      {label:"Creator\nCenter",      x:rzX+2*BW+INNER+170,y:N_Y,       w:70, h:54,        f:"#EFF6FF",s:"#BFDBFE",t:"#1D4ED8"},
      // ── Outdoor zones ───────────────────────────────────────────────────
      {label:"Activity Zone",        x:odZoneX+4,       y:N_Y,   w:90, h:lBot-N_Y,        f:"#FFF7ED",s:"#FED7AA",t:"#C2410C"},
      {label:"Itasha Zone",          x:odZoneX+4,       y:stripY,w:90, h:stripH,           f:"#FDF2F8",s:"#FBCFE8",t:"#BE185D"},
      {label:"Comipara\nFood Market\nFestival", x:odZoneX+100, y:stripY, w:CW-odZoneX-108, h:stripH, f:"#FFFBEB",s:"#FDE68A",t:"#92400E"},
    ];
  },[]);

  const sp=showPath&&fullPath.length>=2?svgPath(fullPath):"";
  const midY=(UY+UPPER_ROWS*(BH+BG)+LY)/2;

  return(
    <div className="flex flex-col bg-gray-50 overflow-hidden" style={{height:"100dvh"}}>
      {/* HEADER */}
      <div className="bg-white px-5 py-3 flex items-center justify-between shrink-0 shadow-sm z-20">
        <div>
          <h1 className="text-base font-extrabold text-gray-900 tracking-tight flex items-center gap-2">Comipara 6 <span className="text-[10px] font-semibold tracking-wider uppercase bg-violet-100 text-violet-700 px-2 py-0.5 rounded-full">Map</span></h1>
          <p className="text-[11px] text-gray-500 font-medium mt-0.5">Tap 1× pilih · Tap 2× detail · 2 jari zoom</p>
        </div>
        <button onClick={resetView} className="text-xs font-semibold px-3 py-1.5 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 active:scale-95 transition-all shadow-sm">Reset View</button>
      </div>

      {/* CONTROLS */}
      <div className="bg-white border-b border-gray-100 px-4 py-3 shrink-0 z-10 space-y-3">
        <div className="flex gap-1 bg-gray-100/80 rounded-lg p-1 w-fit border border-gray-200/60">
          {[["search","🔍 Fandom"],["path","🗺️ Navigasi Jalur"]].map(([t,l])=>(
            <button key={t} onClick={()=>{setTab(t);if(t==="search")resetPath();}}
              className={`px-3.5 py-1.5 rounded-md text-xs font-bold transition-all ${tab===t?"bg-white text-gray-900 shadow-sm border border-gray-200/50":"text-gray-500 hover:text-gray-700"}`}>{l}</button>
          ))}
        </div>

        {tab==="search"&&(
          <div className="space-y-2">
            <div className="relative flex gap-2">
              <div className="relative flex-1">
                <input ref={searchRef} value={search} onChange={e=>{setSearch(e.target.value);setSelFandom(null);setShowSugg(true);}} onFocus={()=>setShowSugg(true)} onBlur={()=>setTimeout(()=>setShowSugg(false),150)} placeholder="Ketik fandom... (e.g. Genshin, Holo)" className="w-full px-3 py-2 text-sm border border-gray-300 rounded-xl bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-violet-400 focus:border-violet-400 transition-shadow"/>
                {showSugg&&suggestions.length>0&&(
                  <div className="absolute top-full left-0 right-0 mt-1.5 bg-white border border-gray-200 rounded-xl shadow-xl z-50 overflow-hidden">
                    {suggestions.map(f=><button key={f} onMouseDown={()=>selectSuggestion(f)} className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-violet-50 hover:text-violet-700 flex items-center gap-2 border-b border-gray-50 last:border-0 font-medium"><span className="text-gray-300 text-xs">🔍</span>{f}{(getSearchCounts()[f]||0)>0&&<span className="ml-auto text-[10px] font-bold text-gray-300 bg-gray-100 px-1.5 py-0.5 rounded">{getSearchCounts()[f]}×</span>}</button>)}
                  </div>
                )}
              </div>
              <button onClick={()=>{setSearch("");setSelFandom(null);setSelectedId(null);setSuggestions([]);}} className="px-4 py-2 text-sm font-semibold border border-gray-300 rounded-xl text-gray-600 hover:bg-gray-50 shadow-sm">Reset</button>
            </div>
            <div className="flex flex-wrap gap-1.5 max-h-[4rem] overflow-y-auto pb-1">
              {topFandoms.map(f=><button key={f} onClick={()=>selectSuggestion(f)} className={`px-2.5 py-1 rounded-full text-[11px] font-semibold border transition-all shadow-sm ${(selFandom===f||search===f)?"bg-violet-600 border-violet-600 text-white":"bg-white border-gray-200 text-gray-600 hover:border-violet-300 hover:bg-violet-50"}`}>{f}</button>)}
            </div>
            {searchTerm&&<p className="text-xs text-gray-500 font-medium">{matchedSet.size>0?<><span className="text-violet-600 font-bold">{matchedSet.size} booth</span> ditemukan untuk "{searchTerm}"</>:<span className="text-rose-500 font-bold">Tidak ada hasil</span>}</p>}
          </div>
        )}

        {tab==="path"&&(
          <div className="space-y-2 bg-gray-50 p-3 rounded-xl border border-gray-100">
            <p className="text-[11px] font-medium text-gray-500">Tap 2 booth di peta atau masukkan ID manual:</p>
            <div className="flex gap-2 flex-wrap items-center">
              <div className="flex items-center gap-2 flex-1 min-w-[110px] bg-white px-2 py-1.5 border border-gray-200 rounded-lg shadow-sm">
                <span className="w-5 h-5 rounded-full bg-emerald-500 text-white text-[10px] font-bold flex items-center justify-center shrink-0">A</span>
                <input value={pathFrom} onChange={e=>setPathFrom(e.target.value.toUpperCase())} placeholder="Mulai (e.g. A01, S01)" className="flex-1 text-sm bg-transparent border-none focus:outline-none uppercase font-semibold text-gray-700 placeholder:normal-case placeholder:font-normal"/>
              </div>
              <div className="flex items-center gap-2 flex-1 min-w-[110px] bg-white px-2 py-1.5 border border-gray-200 rounded-lg shadow-sm">
                <span className="w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center shrink-0">B</span>
                <input value={pathTo} onChange={e=>setPathTo(e.target.value.toUpperCase())} placeholder="Tujuan (e.g. M32, R05)" className="flex-1 text-sm bg-transparent border-none focus:outline-none uppercase font-semibold text-gray-700 placeholder:normal-case placeholder:font-normal"/>
              </div>
              <button onClick={handleFindPath} disabled={!pathFrom||!pathTo} className="px-4 py-2.5 text-xs font-bold bg-violet-600 text-white rounded-lg hover:bg-violet-700 disabled:opacity-40 shadow-sm transition-colors">Cari Rute</button>
              <button onClick={resetPath} className="px-3 py-2.5 text-xs font-bold border border-gray-300 bg-white rounded-lg text-gray-600 hover:bg-gray-50 shadow-sm">Reset</button>
            </div>
            {showPath&&dispPath.length>0&&(
              <div className="flex gap-1 flex-wrap items-center pt-1 border-t border-gray-200">
                <span className="text-xs font-medium text-gray-500">{dispPath.length} titik:</span>
                <div className="flex gap-1 flex-wrap max-h-10 overflow-hidden">
                  {dispPath.map((id,i)=><span key={id} className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${i===0?"bg-emerald-100 text-emerald-700":i===dispPath.length-1?"bg-rose-100 text-rose-700":"bg-amber-100 text-amber-700"}`}>{id}</span>)}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* LEGEND */}
      <div className="flex gap-4 px-4 py-2 bg-gray-50/80 border-b border-gray-200 shrink-0 overflow-x-auto shadow-inner">
        {[{c:"bg-[#F3E8FF] border border-[#D8B4FE]",l:"Terisi"},{c:"bg-[#7C3AED]",l:"Hasil Cari",t:"text-white"},{c:"bg-[#A78BFA]",l:"Dipilih",t:"text-white"},{c:"bg-[#10B981]",l:"Titik A",t:"text-white"},{c:"bg-[#EF4444]",l:"Titik B",t:"text-white"},{c:"bg-[#F59E0B]",l:"Jalur",t:"text-white"}].map(({c,l,t})=>(
          <div key={l} className="flex items-center gap-1.5 shrink-0">
            <div className={`w-4 h-3.5 rounded-sm ${c} ${t||""}`}/>
            <span className="text-[10px] font-bold tracking-wide uppercase whitespace-nowrap text-gray-600">{l}</span>
          </div>
        ))}
      </div>

      {/* MAP */}
      <div ref={containerRef} className="flex-1 overflow-hidden relative select-none touch-none bg-[#E2E8F0] shadow-inner" style={{minHeight:0}}>
        <svg width="100%" height="100%" style={{display:"block"}}>
          <defs>
            <filter id="shadow"><feDropShadow dx="0" dy="8" stdDeviation="12" floodColor="#0F172A" floodOpacity="0.08"/></filter>
            <pattern id="dotGrid" x="0" y="0" width="16" height="16" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r="1" fill="#CBD5E1" opacity="0.6"/></pattern>
          </defs>
          <g transform={`translate(${tx},${ty}) scale(${scale})`}>
            <rect x={0} y={0} width={CW} height={CH} fill="#FFFFFF" rx={16} filter="url(#shadow)"/>
            <rect x={0} y={0} width={CW} height={CH} fill="url(#dotGrid)" rx={16}/>

            {/* INDOOR / OUTDOOR header labels */}
            <text x={MER_X} y={12} fontSize={11} fill="#1E293B" fontWeight={900} letterSpacing={3} fontFamily="system-ui,sans-serif">INDOOR</text>
            <text x={MER_X} y={N_Y+BH+8} fontSize={7.5} fill="#A78BFA" fontWeight={800} letterSpacing={2} fontFamily="system-ui,sans-serif">BARIS N & O</text>
            {/* Vertical "WACOM COMIC HALL" label */}
            <text textAnchor="middle" fontSize={7} fill="#A78BFA" fontWeight={800} letterSpacing={2} fontFamily="system-ui,sans-serif"
              transform={`translate(${LEFT_MARGIN-10},${(UY+LY+UPPER_ROWS*(BH+BG))/2}) rotate(-90)`}>WACOM COMIC HALL</text>
            {/* Creator Merchant Area divider */}
            <line x1={MER_X-6} y1={midY} x2={RZ_X-6} y2={midY} stroke="#CBD5E1" strokeWidth={1.5} strokeDasharray="8 6"/>
            <text x={(MER_X+RZ_X)/2} y={midY+10} textAnchor="middle" fontSize={7} fill="#94A3B8" fontWeight={800} letterSpacing={3} fontFamily="system-ui,sans-serif">CREATOR MERCHANT AREA</text>

            {/* Outdoor thick separator line */}
            <rect x={OD_SEP_X} y={0} width={OUTDOOR_SEP} height={CH} fill="#1E293B" opacity={0.08} rx={2}/>
            <line x1={OD_SEP_X+OUTDOOR_SEP/2} y1={0} x2={OD_SEP_X+OUTDOOR_SEP/2} y2={CH} stroke="#334155" strokeWidth={3}/>
            <text x={OD_ZONE_X+8} y={12} fontSize={11} fill="#0369A1" fontWeight={900} letterSpacing={3} fontFamily="system-ui,sans-serif">OUTDOOR</text>

            {/* Zones */}
            {zones.map(({label,x,y,w,h,f,s,t},i)=>{
              const lines=label.split("\n");
              const fs=Math.min(6.5, Math.max(4.5, Math.min(w/lines.reduce((a,l)=>Math.max(a,l.length),0)*1.4, h/lines.length*0.55)));
              return<g key={i}>
                <rect x={x} y={y} width={w} height={h} rx={6} fill={f} stroke={s} strokeWidth={1.5}/>
                {lines.map((line,li)=><text key={li} x={x+w/2} y={y+h/2+(li-(lines.length-1)/2)*(fs+2)} textAnchor="middle" dominantBaseline="central" fontSize={fs} fill={t} fontWeight={700} fontFamily="system-ui,sans-serif" letterSpacing={0.3}>{line.toUpperCase()}</text>)}
              </g>;
            })}

            {/* Entry/Exit labels */}
            <g transform={`translate(${MER_X+30},${CH-15})`}><rect x={-20} y={-8} width={110} height={16} rx={8} fill="#F1F5F9" stroke="#E2E8F0" strokeWidth={1}/><text x={35} y={0} fontSize={7} fill="#475569" fontWeight={800} textAnchor="middle" dominantBaseline="central" letterSpacing={1} fontFamily="system-ui,sans-serif">▲ ENTRY — HALL A</text></g>
            <g transform={`translate(${MER_X+330},${CH-15})`}><rect x={-20} y={-8} width={80} height={16} rx={8} fill="#F1F5F9" stroke="#E2E8F0" strokeWidth={1}/><text x={20} y={0} fontSize={7} fill="#475569" fontWeight={800} textAnchor="middle" dominantBaseline="central" letterSpacing={1} fontFamily="system-ui,sans-serif">HALL B</text></g>
            <g transform={`translate(${MER_X+600},${CH-15})`}><rect x={-20} y={-8} width={80} height={16} rx={8} fill="#F1F5F9" stroke="#E2E8F0" strokeWidth={1}/><text x={20} y={0} fontSize={7} fill="#475569" fontWeight={800} textAnchor="middle" dominantBaseline="central" letterSpacing={1} fontFamily="system-ui,sans-serif">HALL C</text></g>
            <g transform={`translate(${CW-50},${CH-15})`}><rect x={-10} y={-8} width={58} height={16} rx={8} fill="#FEF2F2" stroke="#FECACA" strokeWidth={1}/><text x={19} y={0} fontSize={7} fill="#B91C1C" fontWeight={800} textAnchor="middle" dominantBaseline="central" letterSpacing={1} fontFamily="system-ui,sans-serif">EXIT ▼</text></g>

            {/* Booths */}
            {ALL_BOOTHS.map(id=><BoothRect key={id} id={id} state={getState(id)} onClick={handleBoothClick}/>)}

            {/* Path */}
            {showPath&&sp&&(<>
              <path d={sp} fill="none" stroke="#FBBF24" strokeWidth={12} strokeOpacity={0.2} strokeLinecap="round" strokeLinejoin="round"/>
              <path d={sp} fill="none" stroke="#F59E0B" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" strokeDasharray="10 6" style={{animation:"dashAnim 1s linear infinite"}}/>
              {ALL_NODES[pathFrom]&&<circle cx={ALL_NODES[pathFrom].cx} cy={ALL_NODES[pathFrom].cy} r={9} fill="#10B981" stroke="#FFF" strokeWidth={2.5}/>}
              {ALL_NODES[pathTo]&&<circle cx={ALL_NODES[pathTo].cx} cy={ALL_NODES[pathTo].cy} r={9} fill="#EF4444" stroke="#FFF" strokeWidth={2.5}/>}
            </>)}
          </g>
        </svg>
        <style>{`@keyframes dashAnim{to{stroke-dashoffset:-32}}@keyframes slideUp{from{transform:translateY(100%);opacity:0}to{transform:translateY(0);opacity:1}}`}</style>
      </div>

      {/* BOTTOM PANEL */}
      {selectedId&&!modalId&&(
        <div className="absolute bottom-4 left-4 right-4 sm:left-auto sm:right-6 sm:w-80 bg-white border border-gray-100 rounded-2xl p-4 z-20 shadow-2xl" style={{animation:"slideUp .3s cubic-bezier(.16,1,.3,1) forwards"}}>
          <div className="flex items-start justify-between mb-2">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-lg font-extrabold text-gray-900">Booth {selectedId}</span>
                {tenants[selectedId]&&<span className="text-sm font-bold text-violet-600">{tenants[selectedId].user}</span>}
              </div>
              {tenants[selectedId]?.allBooths?.length>1&&(
                <div className="flex gap-1 mt-1 flex-wrap">
                  {tenants[selectedId].allBooths.map(b=><span key={b} className={`text-[10px] px-2 py-0.5 rounded font-bold border ${b===selectedId?"bg-violet-600 border-violet-600 text-white":"bg-violet-50 border-violet-200 text-violet-700"}`}>{b}</span>)}
                </div>
              )}
            </div>
            <button onClick={()=>setSelectedId(null)} className="w-7 h-7 flex items-center justify-center rounded-full bg-gray-100 text-gray-400 hover:bg-gray-200 shrink-0 transition-colors">✕</button>
          </div>
          {tenants[selectedId]&&<>
            <div className="flex gap-1.5 mb-3 flex-wrap">{tenants[selectedId].fandoms.map(f=><span key={f} className="text-[10px] font-bold px-2 py-0.5 bg-violet-50 border border-violet-100 text-violet-600 rounded-full">{f}</span>)}</div>
            <button onClick={()=>{setModalId(selectedId);setSelectedId(null);}} className="w-full py-2.5 bg-violet-600 text-white text-sm font-bold rounded-xl shadow-sm shadow-violet-200 hover:bg-violet-700 active:scale-[0.98] transition-all">Lihat Detail & Katalog</button>
          </>}
          {!tenants[selectedId]&&<p className="text-xs text-gray-400 font-medium mt-1">Booth ini masih kosong.</p>}
        </div>
      )}

      {modalId&&tenants[modalId]&&<BoothModal boothId={modalId} tenant={tenants[modalId]} onClose={()=>setModalId(null)} onNavigate={id=>{setTab("path");setPathTo(id);setModalId(null);}}/>}
    
    {/* MAP TIP NOTIFICATION */}
      {showMapTip&&(
        <div className="fixed inset-0 z-50 flex items-end justify-center pb-8 px-4 pointer-events-none">
          <div className="pointer-events-auto w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden animate-[slideUp_0.35s_cubic-bezier(0.34,1.56,0.64,1)_both]"
            style={{animation:"slideUp 0.35s cubic-bezier(0.34,1.56,0.64,1) both"}}>
            <style>{`@keyframes slideUp{from{opacity:0;transform:translateY(40px)}to{opacity:1;transform:translateY(0)}}`}</style>
            {/* Header */}
            <div className="bg-violet-600 px-5 py-4 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-xl shrink-0">🗺️</div>
              <div>
                <p className="text-white font-extrabold text-sm tracking-tight">Cara Menggunakan Map</p>
                <p className="text-violet-200 text-[11px] font-medium">Panduan navigasi cepat</p>
              </div>
            </div>
            {/* Tips */}
            <div className="px-5 py-4 space-y-3">
              <div className="flex items-start gap-3 bg-violet-50 rounded-xl p-3 border border-violet-100">
                <span className="text-2xl shrink-0 mt-0.5">🤌</span>
                <div>
                  <p className="text-[13px] font-bold text-gray-800">Perbesar & Perkecil</p>
                  <p className="text-[11px] text-gray-500 font-medium leading-relaxed">Jepitkan dua jari untuk memperbesar, dan jepitkan lagi untuk memperkecil maps</p>
                </div>
              </div>
              <div className="flex items-start gap-3 bg-blue-50 rounded-xl p-3 border border-blue-100">
                <span className="text-2xl shrink-0 mt-0.5">☝️</span>
                <div>
                  <p className="text-[13px] font-bold text-gray-800">Geser Peta</p>
                  <p className="text-[11px] text-gray-500 font-medium leading-relaxed">Gunakan 1 jari untuk menggeser maps ke atas maupun ke bawah</p>
                </div>
              </div>
            </div>
            {/* Button */}
            <div className="px-5 pb-5">
              <button
                onClick={()=>setShowMapTip(false)}
                className="w-full py-3 bg-violet-600 text-white text-sm font-extrabold rounded-xl shadow-sm shadow-violet-200 hover:bg-violet-700 active:scale-[0.98] transition-all tracking-wide"
              >Mengerti, Mulai Jelajah!</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}